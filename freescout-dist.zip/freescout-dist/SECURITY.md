# Security Policy

## Reporting a Vulnerability

Email at support@freescout.net